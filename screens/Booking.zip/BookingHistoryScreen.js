import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const BookingHistoryScreen = () => {
  return (
    <View>
      <Text>BookingHistoryScreen</Text>
    </View>
  )
}

export default BookingHistoryScreen

const styles = StyleSheet.create({})