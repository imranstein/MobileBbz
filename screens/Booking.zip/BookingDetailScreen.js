import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const BookingDetailScreen = () => {
  return (
    <View>
      <Text>BookingDetailScreen</Text>
    </View>
  )
}

export default BookingDetailScreen

const styles = StyleSheet.create({})